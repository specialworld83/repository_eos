<?xml version="1.0" ?><!DOCTYPE TS><TS language="nb" version="2.1">
<context>
    <name>AccountTypeDialog</name>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="14"/>
        <source>Account Type</source>
        <translation>Kontotype</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="64"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="69"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="79"/>
        <source>Show Groups</source>
        <translation>Vis grupper</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="93"/>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="98"/>
        <source>Member</source>
        <translation>Medlem</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="115"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="135"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="136"/>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="167"/>
        <source>Warning!</source>
        <translation>Advarsel!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="137"/>
        <source>Admin group %1 isn&apos;t enabled in &apos;%2&apos;! You have to enable it to be able to set admin rights...</source>
        <translation>Admin gruppe %1 er ikke aktivert i &apos;% 2&apos;! Du må aktivere den for å være i stand til å sette administratorrettigheter...</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="168"/>
        <source>Following default user groups have been disabled:
%1
It is recommended to enable those groups. Do you really want to continue?</source>
        <translation>Følgende standard brukergrupper har blitt deaktivert:
%1
Det anbefales å aktivere disse gruppene. Ønsker du virkelig å fortsette?</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Error!</source>
        <translation>Feil!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Failed to set groups!</source>
        <translation>Klarte ikke å angi grupper!</translation>
    </message>
</context>
<context>
    <name>ActionDialog</name>
    <message>
        <location filename="../ActionDialog.cpp" line="39"/>
        <source>Do you really want to continue?</source>
        <translation>Vil du virkelig fortsette?</translation>
    </message>
    <message>
        <location filename="../ActionDialog.cpp" line="87"/>
        <source>Done ...</source>
        <translation>Ferdig...</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="14"/>
        <source>Add User</source>
        <translation>Legg til bruker</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="71"/>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="93"/>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="115"/>
        <source>Retype Password</source>
        <translation>Skriv passord på nytt</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="164"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="184"/>
        <source>Create</source>
        <translation>Lag</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="87"/>
        <source>Your username contains invalid characters!</source>
        <translation>Brukernavnet inneholder ugyldige tegn!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="91"/>
        <source>Your passwords do not match!</source>
        <translation>Passordene stemmer ikke overens!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="96"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Error!</source>
        <translation>Feil!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <source>Failed to add user!</source>
        <translation>Klarte ikke å legge til bruker!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Klarte ikke å angi brukerens passord!</translation>
    </message>
</context>
<context>
    <name>ChangePasswordDialog</name>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="14"/>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="74"/>
        <source>New Password</source>
        <translation>Nytt passord</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="96"/>
        <source>Retype Password</source>
        <translation>Skriv passord på nytt</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="149"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Error!</source>
        <translation>Feil!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <source>Your passwords do not match!</source>
        <translation>Passordene stemmer ikke overens!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Klarte ikke å angi brukerens passord!</translation>
    </message>
</context>
<context>
    <name>KernelCommon</name>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="39"/>
        <source>Kernel</source>
        <translation>Kjerne</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="46"/>
        <source>Add and remove Condres kernels</source>
        <translation>Legg til og fjern Condress kjerner</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="77"/>
        <source>Install Linux %1</source>
        <translation>Installer Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="78"/>
        <source>The following packages will be installed:</source>
        <translation>Følgende pakker vil bli installert:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="113"/>
        <source>Remove Linux %1</source>
        <translation>Fjern Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="114"/>
        <source>The following packages will be removed:</source>
        <translation>Følgende pakker vil bli fjernet:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="146"/>
        <source>Linux %1.%2 changelog</source>
        <translation>Linux %1.%2 endringslogg</translation>
    </message>
</context>
<context>
    <name>KernelListViewDelegate</name>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="95"/>
        <source>LTS</source>
        <translation>LTS</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="96"/>
        <source>Recommended</source>
        <translation>Anbefalt</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="97"/>
        <source>Running</source>
        <translation>Kjører</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="98"/>
        <source>Installed</source>
        <translation>Installert</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="99"/>
        <source>Unsupported</source>
        <translation>Ustøttet</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="102"/>
        <source>Real-time</source>
        <translation>Sanntidskjerne</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="200"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="271"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="100"/>
        <source>Custom</source>
        <translation>Tilpasset</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="101"/>
        <source>Experimental</source>
        <translation>Eksperimentell</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="198"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="269"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="199"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="270"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
</context>
<context>
    <name>KeyboardCommon</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="33"/>
        <source>Keyboard Settings</source>
        <translation>Tastaturoppsett</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="40"/>
        <source>Keyboard settings</source>
        <translation>Tastaturoppsett</translation>
    </message>
</context>
<context>
    <name>KeyboardModel</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="220"/>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="264"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="306"/>
        <source>Default Keyboard Model</source>
        <translation>Standard Keyboard Modell</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="515"/>
        <source>Error!</source>
        <translation>Feil!</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="516"/>
        <source>Failed to set keyboard layout</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>LanguageListViewDelegate</name>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="96"/>
        <source>Display Language</source>
        <translation>Visningsspråk</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="99"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="101"/>
        <source>Collation and Sorting</source>
        <translation>Samler og Sorterer</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="102"/>
        <source>Messages</source>
        <translation>Meldinger</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="132"/>
        <source>Formats</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="135"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="136"/>
        <source>Identification</source>
        <translation>Identifikasjon</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="137"/>
        <source>Measurement Units</source>
        <translation>Måleenheter</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="138"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="139"/>
        <source>Names</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="140"/>
        <source>Numbers</source>
        <translation>Nummer</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="141"/>
        <source>Paper</source>
        <translation>Papir</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="142"/>
        <source>Telephone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="143"/>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
</context>
<context>
    <name>LanguagePackagesCommon</name>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="45"/>
        <source>Language Packages</source>
        <translation>Språkpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="52"/>
        <source>Detection and installation of language packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="107"/>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="109"/>
        <source>%1 language packages</source>
        <translation>%1 språkpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="160"/>
        <source>Global language packages</source>
        <translation>Globale språkpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="182"/>
        <source>System is out-of-date</source>
        <translation>Systemet er utdatert</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="183"/>
        <source>Your System is not up-to-date! You have to update it first to continue!</source>
        <translation>Systemet ditt er utdatert! Du må først oppdatere det for å kunne fortsette.</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="215"/>
        <source>Install language packages.</source>
        <translation>Installer språkpakker.</translation>
    </message>
</context>
<context>
    <name>LocaleCommon</name>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="33"/>
        <source>Locale Settings</source>
        <translation>Lokale innstillinger</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="40"/>
        <source>Add and configure locales</source>
        <translation>Legg til og konfigurer regionaldata</translation>
    </message>
</context>
<context>
    <name>LocaleModule</name>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="35"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="42"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="49"/>
        <source>Restore</source>
        <translation>Gjenopprett</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="62"/>
        <source>System Locales</source>
        <translation>Regionaldata for systemet</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="125"/>
        <source>Detailed Settings</source>
        <translation>Detaljerte innstillinger</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="170"/>
        <source>Display Language</source>
        <translation>Visningsspråk</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="188"/>
        <source>Language:</source>
        <translation>Språk:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="198"/>
        <source>Collation and Sorting:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="208"/>
        <source>Messages:</source>
        <translation>Meldinger:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="218"/>
        <source>CType:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="231"/>
        <source>Formats</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="249"/>
        <source>Numbers:</source>
        <translation>Nummer:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="259"/>
        <source>Time:</source>
        <translation>Tid:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="269"/>
        <source>Currency:</source>
        <translation>Valuta:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="279"/>
        <source>Measurement Units:</source>
        <translation>Måleenheter:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="289"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="299"/>
        <source>Names:</source>
        <translation>Navn:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="309"/>
        <source>Telephone:</source>
        <translation>Telefon:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="319"/>
        <source>Identification:</source>
        <translation>Identifikasjon:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="329"/>
        <source>Paper:</source>
        <translation>Papir:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="363"/>
        <source>Set as default display language and format</source>
        <translation>Bruk som standardspråk for visning og formatering</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="368"/>
        <source>Set as default display language</source>
        <translation>Bruk som standardspråk for visning</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="373"/>
        <source>Set as default format</source>
        <translation>Bruk som standardspråk for formatering</translation>
    </message>
</context>
<context>
    <name>MhwdCommon</name>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="39"/>
        <source>Hardware Configuration</source>
        <translation>Maskinvareoppsett</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="46"/>
        <source>Condres Hardware Detection graphical user interface</source>
        <translation>Grensesnitt for Condres Hardware Detection</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="83"/>
        <source>Unknown device name</source>
        <translation>Ukjent enhetsnavn</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="142"/>
        <source>Install configuration</source>
        <translation>Installasjons konfigurasjon</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="143"/>
        <source>MHWD will install the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="165"/>
        <source>Install open-source graphic driver</source>
        <translation>Installer skjermkortdriver med åpen kildekode</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="166"/>
        <source>MHWD will autodetect your open-source graphic drivers and install it</source>
        <translation>MHWD vil finne og installere skjermdrivere med åpen kildekode</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="187"/>
        <source>Install proprietary graphic driver</source>
        <translation>Installer produsenteid skjermdriver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="188"/>
        <source>MHWD will autodetect your proprietary graphic drivers and install it</source>
        <translation>MHWD vil finne og installere produsenteide skjermdrivere</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="209"/>
        <source>Reinstall configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="210"/>
        <source>MHWD will reinstall the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="232"/>
        <source>Remove configuration</source>
        <translation>Fjern Konfigurasjon</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="233"/>
        <source>MHWD will remove the &apos;%1&apos; configuration</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MsmCommon</name>
    <message>
        <location filename="../MsmCommon.cpp" line="26"/>
        <source>Please use &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; to report bugs.</source>
        <translation>Vennligst bruk &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; for og raportere feil.</translation>
    </message>
</context>
<context>
    <name>MsmWindow</name>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="14"/>
        <source>Condres Settings Manager</source>
        <translation>Condres Innstillinger</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="185"/>
        <source>All Settings</source>
        <translation>Alle innstillinger</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="211"/>
        <location filename="../../msm/MsmWindow.ui" line="235"/>
        <source>Quit</source>
        <translation>Avslutt</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="224"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="44"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="50"/>
        <source>Hardware</source>
        <translation>Maskinvare</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="153"/>
        <source>Condres Settings</source>
        <translation>Condres Innstillinger</translation>
    </message>
</context>
<context>
    <name>Notifier</name>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="47"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="47"/>
        <source>Kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="51"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="51"/>
        <source>Language packages</source>
        <translation>Språkpakker</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="55"/>
        <source>Quit</source>
        <translation>Avslutt</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="59"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="56"/>
        <source>Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="191"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="230"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="238"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="291"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="40"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="181"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="220"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="228"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="281"/>
        <source>Condres Settings Manager</source>
        <translation type="unfinished"/>
    </message>
    <message numerus="yes">
        <location filename="../../notifier/notifier/Notifier.cpp" line="192"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="182"/>
        <source>%n new additional language package(s) available</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="231"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="221"/>
        <source>Running an unsupported kernel, please update.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="239"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="229"/>
        <source>Unsupported kernel installed in your system, please remove it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="292"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="282"/>
        <source>Newer kernel is available, please update.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>NotifierSettingsDialog</name>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="20"/>
        <source>Kernel Notifications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="26"/>
        <source>Check unsupported kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="51"/>
        <source>Only notify if running an unsupported kernel</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="60"/>
        <source>Check new kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="85"/>
        <source>Only notify LTS kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="112"/>
        <source>Only notify recommended kernels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="124"/>
        <source>Language Packs Notifications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="130"/>
        <source>Check missing language packs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="168"/>
        <source>Quit</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="181"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="32"/>
        <source>Notifications settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="107"/>
        <source>Format error when saving your notifications settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="111"/>
        <source>Access error when saving your notifications settings</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PageKeyboard</name>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="25"/>
        <source>Keyboard Model:</source>
        <translation>Tastaturmodell:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Skriv her for å prøve ditt tastatur</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="140"/>
        <source>Delay:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="158"/>
        <source>Delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="165"/>
        <source>Set delay</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="183"/>
        <source>Rate:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="201"/>
        <source>Rate  </source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="208"/>
        <source>Set Rate</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PageLanguagePackages</name>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="24"/>
        <source>Available Language Packages</source>
        <translation>Tilgjengelige Språkpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="32"/>
        <source>Additional language packages can be installed:</source>
        <translation>Ekstra språkpakker kan installeres:</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="55"/>
        <source>Install Packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="80"/>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="128"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="85"/>
        <source>Description</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="133"/>
        <source>Parent Package</source>
        <translation>Forelder Pakke</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="90"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="99"/>
        <source>Installed Language Packages</source>
        <translation>Installerte Språkpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="105"/>
        <source>Installed language packages:</source>
        <translation>Installerte språkpakker:</translation>
    </message>
</context>
<context>
    <name>PageMhwd</name>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="37"/>
        <source>Auto Install
Open-source Driver</source>
        <translation>Autoinstaller
Åpen kildekode-Driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="45"/>
        <source>Auto Install
Proprietary Driver</source>
        <translation>Auto Installer
Proprietær Driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="67"/>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="72"/>
        <source>Open-source</source>
        <translation>Åpen kildekode</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="77"/>
        <source>Installed</source>
        <translation>Installert</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="85"/>
        <source>Show all devices</source>
        <translation>Vis alle enheter</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="104"/>
        <source>Reinstall</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="94"/>
        <source>Install</source>
        <translation>Installer</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="99"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
</context>
<context>
    <name>PageTimeDate</name>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="20"/>
        <source>Time and Date</source>
        <translation>Tid og Dato</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="26"/>
        <source>Set time and date automatically</source>
        <translation>Set tid og dato automatisk</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="148"/>
        <source>Time Zone</source>
        <translation>Tidssone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="197"/>
        <source>Change Time Zone</source>
        <translation>Endre Tidssone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="33"/>
        <source>Hardware clock in local time zone</source>
        <translation>Maskinvareklokke i lokal tidssone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="51"/>
        <source>Time:</source>
        <translation>Tid:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="86"/>
        <source>Date:</source>
        <translation>Dato:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="115"/>
        <source>Hardware clock:</source>
        <translation>Maskinvareklokke:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="122"/>
        <source>Universal time:</source>
        <translation>Universal tid:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="165"/>
        <source>Time zone:</source>
        <translation>Tidssone:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="206"/>
        <source>Country:</source>
        <translation>Land:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="246"/>
        <source>Has daylight time?</source>
        <translation>Har sommertid?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="276"/>
        <source>Is daylight time?</source>
        <translation>Er sommertid?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="306"/>
        <source>Has transitions?</source>
        <translation>Har overganger?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="317"/>
        <source>Next transition:</source>
        <translation>Neste overgang:</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="154"/>
        <source>Image</source>
        <translation>Bilde</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="161"/>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="168"/>
        <source>Account Type</source>
        <translation>Kontotype</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="175"/>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="223"/>
        <source>●●●●●●</source>
        <translation>●●●●●●</translation>
    </message>
</context>
<context>
    <name>PreviewFileDialog</name>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="93"/>
        <source>Width:</source>
        <translation>Bredde:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="94"/>
        <source>Height:</source>
        <translation>Høyde:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="95"/>
        <source>Ratio:</source>
        <translation>Ratio:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="96"/>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="97"/>
        <source>%1 px</source>
        <translation>%1 px</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="98"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
</context>
<context>
    <name>SelectLocalesDialog</name>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="14"/>
        <source>Add Locale</source>
        <translation>Legg til Nasjonale</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="34"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="70"/>
        <source>Territory</source>
        <translation>Territorium</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="122"/>
        <source>Locale:</source>
        <translation>Nasjonale:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="182"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="189"/>
        <source>Add</source>
        <translation>Legg til</translation>
    </message>
</context>
<context>
    <name>TimeDateCommon</name>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="38"/>
        <source>Time and Date</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="45"/>
        <source>Time and date configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="138"/>
        <source>none</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>TimeZoneDialog</name>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="14"/>
        <source>Time Zone Selection</source>
        <translation>Tidssonevalg</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="25"/>
        <source>Region:</source>
        <translation>Region:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="61"/>
        <source>Zone:</source>
        <translation>Sone:</translation>
    </message>
</context>
<context>
    <name>UsersCommon</name>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="47"/>
        <source>User Accounts</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="54"/>
        <source>User accounts configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="135"/>
        <source>Continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="136"/>
        <source>Do you really want to remove the user %1?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="143"/>
        <source>Remove Home?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="144"/>
        <source>Do you want to remove the home folder of the user %1?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="166"/>
        <location filename="../../modules/users/UsersCommon.cpp" line="236"/>
        <source>Error!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="167"/>
        <source>Failed to remove user %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="183"/>
        <source>Images (*.png *.jpg *.bmp)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="237"/>
        <source>Failed to change user image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="248"/>
        <source>Standard</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="267"/>
        <source>Administrator</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>
