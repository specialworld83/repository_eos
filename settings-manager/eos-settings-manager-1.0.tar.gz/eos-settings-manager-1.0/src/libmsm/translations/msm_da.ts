<?xml version="1.0" ?><!DOCTYPE TS><TS language="da" version="2.1">
<context>
    <name>AccountTypeDialog</name>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="14"/>
        <source>Account Type</source>
        <translation>Kontotype</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="64"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="69"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="79"/>
        <source>Show Groups</source>
        <translation>Vis grupper</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="93"/>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="98"/>
        <source>Member</source>
        <translation>Medlem</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="115"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AccountTypeDialog.ui" line="135"/>
        <source>Apply</source>
        <translation>Anvend</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="136"/>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="167"/>
        <source>Warning!</source>
        <translation>Advarsel!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="137"/>
        <source>Admin group %1 isn&apos;t enabled in &apos;%2&apos;! You have to enable it to be able to set admin rights...</source>
        <translation>Administratorgruppe %1 er ikke aktiveret i &apos;%2&apos;! Du skal aktivere den for at kunne sætte administrationsrettigheder...</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="168"/>
        <source>Following default user groups have been disabled:
%1
It is recommended to enable those groups. Do you really want to continue?</source>
        <translation>Følgende standardbrugergrupper er blevet deaktiveret:
%1
Det anbefales at aktivere disse grupper. Vil du virkelig fortsætte?</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Error!</source>
        <translation>Fejl!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AccountTypeDialog.cpp" line="190"/>
        <source>Failed to set groups!</source>
        <translation>Kunne ikke sætte grupper!</translation>
    </message>
</context>
<context>
    <name>ActionDialog</name>
    <message>
        <location filename="../ActionDialog.cpp" line="39"/>
        <source>Do you really want to continue?</source>
        <translation>Vil du virkelig fortsætte?</translation>
    </message>
    <message>
        <location filename="../ActionDialog.cpp" line="87"/>
        <source>Done ...</source>
        <translation>Færdig ...</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="14"/>
        <source>Add User</source>
        <translation>Tilføj bruger</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="71"/>
        <source>Username</source>
        <translation>Brugernavn</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="93"/>
        <source>Password</source>
        <translation>Adgangskode</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="115"/>
        <source>Retype Password</source>
        <translation>Gentast adgangskode</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="164"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/AddUserDialog.ui" line="184"/>
        <source>Create</source>
        <translation>Opret</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="87"/>
        <source>Your username contains invalid characters!</source>
        <translation>Dit brugernavn indeholder ugyldige tegn!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="91"/>
        <source>Your passwords do not match!</source>
        <translation>Dine adgangskoder er ikke ens!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="96"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Error!</source>
        <translation>Fejl!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="119"/>
        <source>Failed to add user!</source>
        <translation>Kunne ikke tilføje bruger!</translation>
    </message>
    <message>
        <location filename="../../modules/users/AddUserDialog.cpp" line="141"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Kunne ikke sætte brugerens adgangskode!</translation>
    </message>
</context>
<context>
    <name>ChangePasswordDialog</name>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="14"/>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="74"/>
        <source>New Password</source>
        <translation>Ny adgangskode</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="96"/>
        <source>Retype Password</source>
        <translation>Gentast adgangskode</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/ChangePasswordDialog.ui" line="149"/>
        <source>Apply</source>
        <translation>Anvend</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Error!</source>
        <translation>Fejl!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="76"/>
        <source>Your passwords do not match!</source>
        <translation>Dine adgangskoder er ikke ens!</translation>
    </message>
    <message>
        <location filename="../../modules/users/ChangePasswordDialog.cpp" line="97"/>
        <source>Failed to set user&apos;s password!</source>
        <translation>Kunne ikke sætte brugerens adgangskode!</translation>
    </message>
</context>
<context>
    <name>KernelCommon</name>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="39"/>
        <source>Kernel</source>
        <translation>Kerne</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="46"/>
        <source>Add and remove Condres kernels</source>
        <translation>Tilføj og fjerne Condres-kerner</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="77"/>
        <source>Install Linux %1</source>
        <translation>Installér Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="78"/>
        <source>The following packages will be installed:</source>
        <translation>Følgende pakker vil blive installeret:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="113"/>
        <source>Remove Linux %1</source>
        <translation>Fjern Linux %1</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="114"/>
        <source>The following packages will be removed:</source>
        <translation>Følgende pakker vil blive fjernet:</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelCommon.cpp" line="146"/>
        <source>Linux %1.%2 changelog</source>
        <translation>Linux %1.%2 ændringslog</translation>
    </message>
</context>
<context>
    <name>KernelListViewDelegate</name>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="95"/>
        <source>LTS</source>
        <translation>LTS</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="96"/>
        <source>Recommended</source>
        <translation>Anbefalet</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="97"/>
        <source>Running</source>
        <translation>Kørende</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="98"/>
        <source>Installed</source>
        <translation>Installeret</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="99"/>
        <source>Unsupported</source>
        <translation>Ikke-understøttet</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="102"/>
        <source>Real-time</source>
        <translation>Realtid</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="200"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="271"/>
        <source>Changelog</source>
        <translation>Ændringslog</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="100"/>
        <source>Custom</source>
        <translation>Brugerdefineret</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="101"/>
        <source>Experimental</source>
        <translation>Eksperimentel</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="198"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="269"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="199"/>
        <location filename="../../modules/kernel/KernelListViewDelegate.cpp" line="270"/>
        <source>Install</source>
        <translation>Installér</translation>
    </message>
</context>
<context>
    <name>KeyboardCommon</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="33"/>
        <source>Keyboard Settings</source>
        <translation>Tastaturindstillinger</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardCommon.cpp" line="40"/>
        <source>Keyboard settings</source>
        <translation>Tastaturindstillinger</translation>
    </message>
</context>
<context>
    <name>KeyboardModel</name>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="220"/>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="264"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="306"/>
        <source>Default Keyboard Model</source>
        <translation>Standardtastaturmodel</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="515"/>
        <source>Error!</source>
        <translation>Fejl!</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/KeyboardModel.cpp" line="516"/>
        <source>Failed to set keyboard layout</source>
        <translation>Kunne ikke sætte tastaturlayout</translation>
    </message>
</context>
<context>
    <name>LanguageListViewDelegate</name>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="96"/>
        <source>Display Language</source>
        <translation>Visningssprog</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="99"/>
        <source>Language</source>
        <translation>Sprog</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="101"/>
        <source>Collation and Sorting</source>
        <translation>Sammenstilling og sortering</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="102"/>
        <source>Messages</source>
        <translation>Beskeder</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="132"/>
        <source>Formats</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="135"/>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="136"/>
        <source>Identification</source>
        <translation>Identifikation</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="137"/>
        <source>Measurement Units</source>
        <translation>Måleenheder</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="138"/>
        <source>Currency</source>
        <translation>Valuta</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="139"/>
        <source>Names</source>
        <translation>Navne</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="140"/>
        <source>Numbers</source>
        <translation>Numre</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="141"/>
        <source>Paper</source>
        <translation>Papir</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="142"/>
        <source>Telephone</source>
        <translation>Telefon</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LanguageListViewDelegate.cpp" line="143"/>
        <source>Time</source>
        <translation>Klokkeslæt</translation>
    </message>
</context>
<context>
    <name>LanguagePackagesCommon</name>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="45"/>
        <source>Language Packages</source>
        <translation>Sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="52"/>
        <source>Detection and installation of language packages</source>
        <translation>Registrering og installation af sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="107"/>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="109"/>
        <source>%1 language packages</source>
        <translation>%1 sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="160"/>
        <source>Global language packages</source>
        <translation>Globale sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="182"/>
        <source>System is out-of-date</source>
        <translation>Systemet er ikke opdateret</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="183"/>
        <source>Your System is not up-to-date! You have to update it first to continue!</source>
        <translation>Dit system er ikke opdateret! Du skal opdatere for at fortsætte!</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/LanguagePackagesCommon.cpp" line="215"/>
        <source>Install language packages.</source>
        <translation>Installér sprogpakker.</translation>
    </message>
</context>
<context>
    <name>LocaleCommon</name>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="33"/>
        <source>Locale Settings</source>
        <translation>Regionsindstillinger</translation>
    </message>
    <message>
        <location filename="../../modules/locale/LocaleCommon.cpp" line="40"/>
        <source>Add and configure locales</source>
        <translation>Tilføj og konfigurér regioner</translation>
    </message>
</context>
<context>
    <name>LocaleModule</name>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="35"/>
        <source>Add</source>
        <translation>Tilføj</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="42"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="49"/>
        <source>Restore</source>
        <translation>Gendan</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="62"/>
        <source>System Locales</source>
        <translation>Systemregioner</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="125"/>
        <source>Detailed Settings</source>
        <translation>Detaljerede indstillinger</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="170"/>
        <source>Display Language</source>
        <translation>Visningssprog</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="188"/>
        <source>Language:</source>
        <translation>Sprog:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="198"/>
        <source>Collation and Sorting:</source>
        <translation>Sammenstilling og sortering:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="208"/>
        <source>Messages:</source>
        <translation>Beskeder:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="218"/>
        <source>CType:</source>
        <translation>CType:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="231"/>
        <source>Formats</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="249"/>
        <source>Numbers:</source>
        <translation>Numre:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="259"/>
        <source>Time:</source>
        <translation>Klokkeslæt:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="269"/>
        <source>Currency:</source>
        <translation>Valuta:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="279"/>
        <source>Measurement Units:</source>
        <translation>Måleenheder:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="289"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="299"/>
        <source>Names:</source>
        <translation>Navne:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="309"/>
        <source>Telephone:</source>
        <translation>Telefon:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="319"/>
        <source>Identification:</source>
        <translation>Identifikation:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="329"/>
        <source>Paper:</source>
        <translation>Papir:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="363"/>
        <source>Set as default display language and format</source>
        <translation>Indstil som standardvisningssprog og format</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="368"/>
        <source>Set as default display language</source>
        <translation>Indstil som standardvisningssprog</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/LocaleModule.ui" line="373"/>
        <source>Set as default format</source>
        <translation>Indstil som standardformat</translation>
    </message>
</context>
<context>
    <name>MhwdCommon</name>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="39"/>
        <source>Hardware Configuration</source>
        <translation>Hardwarekonfiguration</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="46"/>
        <source>Condres Hardware Detection graphical user interface</source>
        <translation>Condres hardwareregistrering grafisk brugerflade</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="83"/>
        <source>Unknown device name</source>
        <translation>Ukendt enhedsnavn</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="142"/>
        <source>Install configuration</source>
        <translation>Installér konfiguration</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="143"/>
        <source>MHWD will install the &apos;%1&apos; configuration</source>
        <translation>MHWD vil installere &quot;%1&quot;-konfigurationen</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="165"/>
        <source>Install open-source graphic driver</source>
        <translation>Installér open source-grafikkortdriver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="166"/>
        <source>MHWD will autodetect your open-source graphic drivers and install it</source>
        <translation>MHWD vil autodetektere dine open source-grafikkortdrivere og installere dem</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="187"/>
        <source>Install proprietary graphic driver</source>
        <translation>Installér proprietær grafikkortdriver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="188"/>
        <source>MHWD will autodetect your proprietary graphic drivers and install it</source>
        <translation>MHWD vil autodetektere dine proprietære grafikkortdrivere og installere dem</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="209"/>
        <source>Reinstall configuration</source>
        <translation>Geninstallér konfiguration</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="210"/>
        <source>MHWD will reinstall the &apos;%1&apos; configuration</source>
        <translation>MHWD vil geninstallere &quot;%1&quot;-konfigurationen</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="232"/>
        <source>Remove configuration</source>
        <translation>Fjern konfiguration</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/MhwdCommon.cpp" line="233"/>
        <source>MHWD will remove the &apos;%1&apos; configuration</source>
        <translation>MHWD vil fjerne &quot;%1&quot;-konfigurationen</translation>
    </message>
</context>
<context>
    <name>MsmCommon</name>
    <message>
        <location filename="../MsmCommon.cpp" line="26"/>
        <source>Please use &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; to report bugs.</source>
        <translation>Brug venligst &lt;a href=&apos;%1&apos;&gt;%1&lt;/a&gt; til at rapportere fejl.</translation>
    </message>
</context>
<context>
    <name>MsmWindow</name>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="14"/>
        <source>Condres Settings Manager</source>
        <translation>Condres-indstillingshåndtering</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="185"/>
        <source>All Settings</source>
        <translation>Alle indstillinger</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="211"/>
        <location filename="../../msm/MsmWindow.ui" line="235"/>
        <source>Quit</source>
        <translation>Afslut</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.ui" line="224"/>
        <source>Apply</source>
        <translation>Anvend</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="44"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="50"/>
        <source>Hardware</source>
        <translation>Hardware</translation>
    </message>
    <message>
        <location filename="../../msm/MsmWindow.cpp" line="153"/>
        <source>Condres Settings</source>
        <translation>Condres-indstillinger</translation>
    </message>
</context>
<context>
    <name>Notifier</name>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="47"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="47"/>
        <source>Kernels</source>
        <translation>Kerner</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="51"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="51"/>
        <source>Language packages</source>
        <translation>Sprogpakker</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="55"/>
        <source>Quit</source>
        <translation>Afslut</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="59"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="56"/>
        <source>Options</source>
        <translation>Valgmuligheder</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="191"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="230"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="238"/>
        <location filename="../../notifier/notifier/Notifier.cpp" line="291"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="40"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="181"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="220"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="228"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="281"/>
        <source>Condres Settings Manager</source>
        <translation>Condres-indstillingshåndtering</translation>
    </message>
    <message numerus="yes">
        <location filename="../../notifier/notifier/Notifier.cpp" line="192"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="182"/>
        <source>%n new additional language package(s) available</source>
        <translation><numerusform>yderligere %n ny sprogpakke tilgængelig</numerusform><numerusform>yderligere %n nye sprogpakker tilgængelige</numerusform></translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="231"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="221"/>
        <source>Running an unsupported kernel, please update.</source>
        <translation>Kører en ikke-understøttet kerne, opdatér venligst.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="239"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="229"/>
        <source>Unsupported kernel installed in your system, please remove it.</source>
        <translation>Ikke-understøttet kerne installeret på dit system, fjern den venligst.</translation>
    </message>
    <message>
        <location filename="../../notifier/notifier/Notifier.cpp" line="292"/>
        <location filename="../../notifier/notifier_kde/Notifier.cpp" line="282"/>
        <source>Newer kernel is available, please update.</source>
        <translation>Ny kerne tilgængelig, opdatér venligst.</translation>
    </message>
</context>
<context>
    <name>NotifierSettingsDialog</name>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="20"/>
        <source>Kernel Notifications</source>
        <translation>Kerne-notifikationer</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="26"/>
        <source>Check unsupported kernels</source>
        <translation>Tjek ikke-understøttede kerner</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="51"/>
        <source>Only notify if running an unsupported kernel</source>
        <translation>Giv kun besked hvis der køres med en kerne som ikke understøttes</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="60"/>
        <source>Check new kernels</source>
        <translation>Tjek nye kerner</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="85"/>
        <source>Only notify LTS kernels</source>
        <translation>Kun besked ved LTS-kerner</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="112"/>
        <source>Only notify recommended kernels</source>
        <translation>Kun besked ved anbefalede kerner</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="124"/>
        <source>Language Packs Notifications</source>
        <translation>Sprogpakker-notifikationer</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="130"/>
        <source>Check missing language packs</source>
        <translation>Tjek manglende sprogpakker</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="168"/>
        <source>Quit</source>
        <translation>Afslut</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.ui" line="181"/>
        <source>Apply</source>
        <translation>Anvend</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="32"/>
        <source>Notifications settings</source>
        <translation>Notifikationsindstillinger</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="107"/>
        <source>Format error when saving your notifications settings</source>
        <translation>Formatfejl da dine notifikationsindstillinger skulle gemmes</translation>
    </message>
    <message>
        <location filename="../NotifierSettingsDialog.cpp" line="111"/>
        <source>Access error when saving your notifications settings</source>
        <translation>Adgangsfejl da dine notifikationsindstillinger skulle gemmes</translation>
    </message>
</context>
<context>
    <name>PageKeyboard</name>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="25"/>
        <source>Keyboard Model:</source>
        <translation>Tastaturmodel:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="131"/>
        <source>Type here to test your keyboard</source>
        <translation>Skriv her for at teste dit tastatur</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="140"/>
        <source>Delay:</source>
        <translation>Forsinkelse:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="158"/>
        <source>Delay</source>
        <translation>Forsinkelse</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="165"/>
        <source>Set delay</source>
        <translation>Indstil forsinkelse</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="183"/>
        <source>Rate:</source>
        <translation>Hastighed:</translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="201"/>
        <source>Rate  </source>
        <translation>Hastighed  </translation>
    </message>
    <message>
        <location filename="../../modules/keyboard/ui/PageKeyboard.ui" line="208"/>
        <source>Set Rate</source>
        <translation>Indstil hastighed</translation>
    </message>
</context>
<context>
    <name>PageLanguagePackages</name>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="24"/>
        <source>Available Language Packages</source>
        <translation>Tilgængelige sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="32"/>
        <source>Additional language packages can be installed:</source>
        <translation>Yderligere sprogpakker der kan installeres:</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="55"/>
        <source>Install Packages</source>
        <translation>Installér pakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="80"/>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="128"/>
        <source>Package</source>
        <translation>Pakke</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="85"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="133"/>
        <source>Parent Package</source>
        <translation>Forældrepakke</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="90"/>
        <source>Install</source>
        <translation>Installér</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="99"/>
        <source>Installed Language Packages</source>
        <translation>Installerede sprogpakker</translation>
    </message>
    <message>
        <location filename="../../modules/language_packages/ui/PageLanguagePackages.ui" line="105"/>
        <source>Installed language packages:</source>
        <translation>Installerede sprogpakker:</translation>
    </message>
</context>
<context>
    <name>PageMhwd</name>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="37"/>
        <source>Auto Install
Open-source Driver</source>
        <translation>Automatisk Installering
Open source-driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="45"/>
        <source>Auto Install
Proprietary Driver</source>
        <translation>Automatisk Installering
Proprietær-driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="67"/>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="72"/>
        <source>Open-source</source>
        <translation>Open source</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="77"/>
        <source>Installed</source>
        <translation>Installeret</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="85"/>
        <source>Show all devices</source>
        <translation>Vis alle enheder</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="104"/>
        <source>Reinstall</source>
        <translation>Geninstallér</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="94"/>
        <source>Install</source>
        <translation>Installér</translation>
    </message>
    <message>
        <location filename="../../modules/mhwd/ui/PageMhwd.ui" line="99"/>
        <source>Remove</source>
        <translation>Fjern</translation>
    </message>
</context>
<context>
    <name>PageTimeDate</name>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="20"/>
        <source>Time and Date</source>
        <translation>Klokkeslæt og dato</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="26"/>
        <source>Set time and date automatically</source>
        <translation>Indstil automatisk klokkeslæt og dato</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="148"/>
        <source>Time Zone</source>
        <translation>Tidszone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="197"/>
        <source>Change Time Zone</source>
        <translation>Skift tidszone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="33"/>
        <source>Hardware clock in local time zone</source>
        <translation>Hardware-ur i lokal tidszone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="51"/>
        <source>Time:</source>
        <translation>Klokkeslæt:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="86"/>
        <source>Date:</source>
        <translation>Dato:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="115"/>
        <source>Hardware clock:</source>
        <translation>Hardware-ur:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="122"/>
        <source>Universal time:</source>
        <translation>Universal tid:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="165"/>
        <source>Time zone:</source>
        <translation>Tidszone:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="206"/>
        <source>Country:</source>
        <translation>Land:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="246"/>
        <source>Has daylight time?</source>
        <translation>Har sommertid?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="276"/>
        <source>Is daylight time?</source>
        <translation>Er sommertid?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="306"/>
        <source>Has transitions?</source>
        <translation>Har overgange?</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/PageTimeDate.ui" line="317"/>
        <source>Next transition:</source>
        <translation>Næste overgang:</translation>
    </message>
</context>
<context>
    <name>PageUsers</name>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="154"/>
        <source>Image</source>
        <translation>Billede</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="161"/>
        <source>Username</source>
        <translation>Brugernavn</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="168"/>
        <source>Account Type</source>
        <translation>Kontotype</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="175"/>
        <source>Password</source>
        <translation>Adgangskode</translation>
    </message>
    <message>
        <location filename="../../modules/users/ui/PageUsers.ui" line="223"/>
        <source>●●●●●●</source>
        <translation>●●●●●●</translation>
    </message>
</context>
<context>
    <name>PreviewFileDialog</name>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="93"/>
        <source>Width:</source>
        <translation>Bredde:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="94"/>
        <source>Height:</source>
        <translation>Højde:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="95"/>
        <source>Ratio:</source>
        <translation>Forhold:</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="96"/>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="97"/>
        <source>%1 px</source>
        <translation>%1 px</translation>
    </message>
    <message>
        <location filename="../../modules/users/PreviewFileDialog.cpp" line="98"/>
        <source>%1</source>
        <translation>%1</translation>
    </message>
</context>
<context>
    <name>SelectLocalesDialog</name>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="14"/>
        <source>Add Locale</source>
        <translation>Tilføj lokalitet</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="34"/>
        <source>Language</source>
        <translation>Sprog</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="70"/>
        <source>Territory</source>
        <translation>Område</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="122"/>
        <source>Locale:</source>
        <translation>Område:</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="182"/>
        <source>Cancel</source>
        <translation>Annuller</translation>
    </message>
    <message>
        <location filename="../../modules/locale/ui/SelectLocalesDialog.ui" line="189"/>
        <source>Add</source>
        <translation>Tilføj</translation>
    </message>
</context>
<context>
    <name>TimeDateCommon</name>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="38"/>
        <source>Time and Date</source>
        <translation>Klokkeslæt og dato</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="45"/>
        <source>Time and date configuration</source>
        <translation>Konfiguration af klokkeslæt og dato</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/TimeDateCommon.cpp" line="138"/>
        <source>none</source>
        <translation>ingen</translation>
    </message>
</context>
<context>
    <name>TimeZoneDialog</name>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="14"/>
        <source>Time Zone Selection</source>
        <translation>Valg af tidszone</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="25"/>
        <source>Region:</source>
        <translation>Region:</translation>
    </message>
    <message>
        <location filename="../../modules/timedate/ui/TimeZoneDialog.ui" line="61"/>
        <source>Zone:</source>
        <translation>Zone:</translation>
    </message>
</context>
<context>
    <name>UsersCommon</name>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="47"/>
        <source>User Accounts</source>
        <translation>Brugerkonti</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="54"/>
        <source>User accounts configuration</source>
        <translation>Konfiguration af brugerkonti</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="135"/>
        <source>Continue?</source>
        <translation>Fortsæt?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="136"/>
        <source>Do you really want to remove the user %1?</source>
        <translation>Vil du virkelig fjerne brugeren %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="143"/>
        <source>Remove Home?</source>
        <translation>Fjern Hjem?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="144"/>
        <source>Do you want to remove the home folder of the user %1?</source>
        <translation>Ønsker du at fjerne hjemmemappen for brugeren %1?</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="166"/>
        <location filename="../../modules/users/UsersCommon.cpp" line="236"/>
        <source>Error!</source>
        <translation>Fejl!</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="167"/>
        <source>Failed to remove user %1</source>
        <translation>Kunne ikke fjerne bruger %1</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="183"/>
        <source>Images (*.png *.jpg *.bmp)</source>
        <translation>Billeder (*.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="237"/>
        <source>Failed to change user image</source>
        <translation>Kunne ikke skifte brugerbillede</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="248"/>
        <source>Standard</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../../modules/users/UsersCommon.cpp" line="267"/>
        <source>Administrator</source>
        <translation>Administrator</translation>
    </message>
</context>
</TS>
